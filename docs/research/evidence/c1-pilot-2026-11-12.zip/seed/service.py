from pathlib import Path
import tomllib

config = Path(__file__).with_name("settings.toml")
print(tomllib.loads(config.read_text())["timeout"])
