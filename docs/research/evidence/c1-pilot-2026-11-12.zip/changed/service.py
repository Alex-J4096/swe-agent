from pathlib import Path
import tomllib

config = Path(__file__).with_name("app.toml")
print(tomllib.loads(config.read_text())["timeout"])
