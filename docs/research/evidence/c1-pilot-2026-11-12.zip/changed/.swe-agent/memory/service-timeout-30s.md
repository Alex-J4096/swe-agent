---
name: service-timeout-30s
description: Service request timeout is 30 seconds across config files
type: project
scope: project
---

The service timeout has been set to 30 seconds in both `settings.toml` and `app.toml`. `service.py` reads the timeout from `settings.toml`; verified output is `30`.
