---
name: config-loading-app-toml-only
description: 服务启动仅读取 app.toml，不加载 settings.toml
type: project
scope: project
---

`service.py` 通过 `Path(__file__).with_name("app.toml")` 定位配置文件，使用 `tomllib` 读取并解析 `app.toml`，提取 `timeout` 键。`settings.toml` 虽然存在且包含相同配置，但启动代码并未引用它。
